from django.test import TestCase

# Create your tests here.
lst = []

if lst:
    print("non empty")
else:
    print("empty")
