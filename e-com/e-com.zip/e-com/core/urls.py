from django.urls import path

from . import views

urlpatterns = [
    # path("ksdh", views.home, name="home"),
]