from django.contrib import admin
from .models import Seller

# Register your models here.
admin.site.register(Seller)